module.exports = require('./lib/wx_jsapi_sign');
