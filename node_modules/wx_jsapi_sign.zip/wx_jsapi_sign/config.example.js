module.exports = function() {
    // 输入你的配置
    return {
        appId: '',
        appSecret: '',
        appToken: 'SHANG',
        cache_json_file:'/tmp'
    };
};